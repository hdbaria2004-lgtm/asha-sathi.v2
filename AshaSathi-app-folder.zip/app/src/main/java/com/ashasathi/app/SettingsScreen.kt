package com.ashasathi.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentLang: String,
    onLangSelected: (String) -> Unit,
    isDarkTheme: Boolean,
    onThemeToggle: (Boolean) -> Unit,
    onLogout: () -> Unit
) {
    var backupStatus by remember { mutableStateOf("15/09/2026 09:30 AM") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        Text(
            text = if (currentLang == "gu") "સેટિંગ્સ અને પસંદગીઓ" else if (currentLang == "hi") "सेटिंग्स एवं प्राथमिकताएं" else "Settings & Preferences",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = if (isDarkTheme) Color.White else Color(0xFF0F172A)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Backup / Restore (Compact)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (currentLang == "gu") "ડેટા બેકઅપ અને સિંક" else if (currentLang == "hi") "डेटा बैकअप एवं सिंक" else "Data Backup & Sync",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text("Last Sync: $backupStatus", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = { backupStatus = "Just Now" },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(
                        text = if (currentLang == "gu") "બેકઅપ લો" else if (currentLang == "hi") "बैकअप लें" else "Backup Now",
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Logout Button (High-contrast, compact accent button)
        Button(
            onClick = onLogout,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
            modifier = Modifier.fillMaxWidth().height(40.dp),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (currentLang == "gu") "ખાતામાંથી લૉગ આઉટ કરો" else if (currentLang == "hi") "लॉग आउट करें" else "Log Out",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
