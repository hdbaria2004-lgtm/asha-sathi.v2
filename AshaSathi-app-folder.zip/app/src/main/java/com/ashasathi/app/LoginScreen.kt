package com.ashasathi.app

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LoginScreen(
    onLoginSuccess: (mobile: String, workerName: String) -> Unit,
    lang: String = "hi",
    onLanguageChange: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("asha_sathi_auth", Context.MODE_PRIVATE) }
    
    // Tab State: 0 = Login, 1 = New Registration
    var activeTab by remember { mutableIntStateOf(0) }
    
    // Login Fields (Single Password Field)
    var loginMobile by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var showLoginPassword by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf("") }
    
    // Registration Fields
    var regName by remember { mutableStateOf("") }
    var regMobile by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var showRegPassword by remember { mutableStateOf(false) }
    var regError by remember { mutableStateOf("") }
    var regSuccess by remember { mutableStateOf("") }

    // Forgot / Reset Password Dialog
    var showForgotDialog by remember { mutableStateOf(false) }
    var forgotMobile by remember { mutableStateOf("") }
    var enteredOtp by remember { mutableStateOf("4821") }
    var newPassword by remember { mutableStateOf("") }
    var showNewPassword by remember { mutableStateOf(false) }
    var forgotError by remember { mutableStateOf("") }

    val primaryTeal = Color(0xFF005D57)

    // Gujarati: "આશા સાથી", Hindi: "आशा साथी", English: "Asha Sathi"
    val appTitle = when (lang) {
        "gu" -> "આશા સાથી"
        "hi" -> "आशा साथी"
        else -> "Asha Sathi"
    }

    val nhmTitle = when (lang) {
        "gu" -> "રાષ્ટ્રીય સ્વાસ્થ્ય મિશન (NHM)"
        "hi" -> "राष्ट्रीय स्वास्थ्य मिशन (NHM)"
        else -> "National Health Mission (NHM)"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .drawBehind {
                val width = size.width
                val height = size.height

                // Subtle top edge cyan/teal tint
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFFE0F7FA).copy(alpha = 0.35f), Color.Transparent),
                        startY = 0f,
                        endY = height * 0.12f
                    )
                )

                // Top subtle decorative wave at the very top edge
                val topWave = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(0f, height * 0.035f)
                    cubicTo(
                        width * 0.35f, height * 0.055f,
                        width * 0.70f, height * 0.02f,
                        width, height * 0.045f
                    )
                    lineTo(width, 0f)
                    close()
                }
                drawPath(topWave, color = Color(0xFF06B6D4).copy(alpha = 0.07f))

                // Bottom soft layered healthcare teal/green waves at the very bottom edge
                val bottomWave1 = Path().apply {
                    moveTo(0f, height * 0.91f)
                    cubicTo(
                        width * 0.30f, height * 0.88f,
                        width * 0.65f, height * 0.94f,
                        width, height * 0.90f
                    )
                    lineTo(width, height)
                    lineTo(0f, height)
                    close()
                }
                drawPath(bottomWave1, color = Color(0xFF38BDF8).copy(alpha = 0.08f))

                val bottomWave2 = Path().apply {
                    moveTo(0f, height * 0.94f)
                    cubicTo(
                        width * 0.25f, height * 0.97f,
                        width * 0.60f, height * 0.92f,
                        width, height * 0.95f
                    )
                    lineTo(width, height)
                    lineTo(0f, height)
                    close()
                }
                drawPath(bottomWave2, color = Color(0xFF14B8A6).copy(alpha = 0.11f))

                val bottomWave3 = Path().apply {
                    moveTo(0f, height * 0.965f)
                    cubicTo(
                        width * 0.35f, height * 0.95f,
                        width * 0.70f, height * 0.985f,
                        width, height * 0.96f
                    )
                    lineTo(width, height)
                    lineTo(0f, height)
                    close()
                }
                drawPath(bottomWave3, color = Color(0xFF005D57).copy(alpha = 0.13f))
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        // --- 1. NHM Header & 3-Language Selector ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "NHM",
                    tint = primaryTeal,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = nhmTitle,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            }

            // Compact Single Language Dropdown Box
            var isLangDropdownOpen by remember { mutableStateOf(false) }
            val currentLangLabel = when (lang) {
                "gu" -> "ગુજરાતી"
                "hi" -> "हिन्दी"
                else -> "English"
            }

            Box {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    shadowElevation = 1.dp,
                    modifier = Modifier.clickable { isLangDropdownOpen = !isLangDropdownOpen }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentLangLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Icon(
                            imageVector = if (isLangDropdownOpen) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = "Dropdown",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = isLangDropdownOpen,
                    onDismissRequest = { isLangDropdownOpen = false }
                ) {
                    listOf("en" to "English", "hi" to "हिन्दी", "gu" to "ગુજરાતી").forEach { (code, label) ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (lang == code) "$label ✓" else label,
                                    fontSize = 12.sp,
                                    fontWeight = if (lang == code) FontWeight.Bold else FontWeight.Normal,
                                    color = if (lang == code) primaryTeal else Color(0xFF1E293B)
                                )
                            },
                            onClick = {
                                sharedPrefs.edit().putString("ashaLang", code).apply()
                                onLanguageChange(code)
                                isLangDropdownOpen = false
                            }
                        )
                    }
                }
            }
        }

        // --- 1. Logo (ImageView): 110dp x 110dp, marginTop -20dp, centerCrop ---
        Box(
            modifier = Modifier
                .offset(y = (-20).dp)
                .size(110.dp)
                .clip(CircleShape)
                .background(Color(0xFF042F2E)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_asha_logo),
                contentDescription = "ASHA Logo",
                modifier = Modifier.size(110.dp),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // --- 2. 'आशा साथी' Main Title (TextView): 18sp bold, marginBottom 2dp ---
        Text(
            text = appTitle,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = primaryTeal
        )

        Spacer(modifier = Modifier.height(2.dp))

        // --- 3. Subtitle (TextView): 'आशा कार्यकर्ता लॉगिन', 12sp, marginBottom 12dp ---
        Text(
            text = when (lang) {
                "gu" -> if (activeTab == 0) "આશા કાર્યકર્તા લૉગિન" else "આશા કાર્યકર્તા નોંધણી"
                "hi" -> if (activeTab == 0) "आशा कार्यकर्ता लॉगिन" else "आशा कार्यकर्ता नया पंजीकरण"
                else -> if (activeTab == 0) "ASHA Worker Login" else "ASHA Worker Registration"
            },
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF64748B)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // --- 4. Login / New Registration Segmented Tabs (Compact 42-44dp) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .background(Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                .padding(2.5.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeTab == 0) Color.White else Color.Transparent)
                    .clickable { 
                        activeTab = 0 
                        loginError = ""
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (activeTab == 0) primaryTeal else Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (lang) {
                            "gu" -> "લૉગિન"
                            "hi" -> "लॉगिन"
                            else -> "Login"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeTab == 0) primaryTeal else Color(0xFF64748B)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeTab == 1) Color.White else Color.Transparent)
                    .clickable { 
                        activeTab = 1 
                        regError = ""
                        regSuccess = ""
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (activeTab == 1) primaryTeal else Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (lang) {
                            "gu" -> "નવી નોંધણી"
                            "hi" -> "नया पंजीकरण"
                            else -> "New Registration"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeTab == 1) primaryTeal else Color(0xFF64748B)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(9.dp))

        // --- 4. Forms Container ---
        if (activeTab == 0) {
            // === LOGIN TAB (ONLY ONE PASSWORD FIELD) ===
            if (loginError.isNotEmpty()) {
                Surface(
                    color = Color(0xFFFFF1F2),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Text(
                        text = loginError,
                        color = Color(0xFFBE123C),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Mobile Number Field (Compact 42-44dp height)
            OutlinedTextField(
                value = loginMobile,
                onValueChange = { if (it.length <= 10) loginMobile = it.filter { ch -> ch.isDigit() } },
                label = { Text(when (lang) {
                    "gu" -> "નોંધાયેલ મોબાઇલ નંબર"
                    "hi" -> "पंजीकृत मोबाइल नंबर"
                    else -> "Registered Mobile Number"
                }, fontSize = 13.sp) },
                leadingIcon = { Text("+91 ", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF64748B), modifier = Modifier.padding(start = 12.dp)) },
                trailingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            )

            Spacer(modifier = Modifier.height(9.dp))

            // SINGLE Password Field on Login (Compact 42-44dp height)
            OutlinedTextField(
                value = loginPassword,
                onValueChange = { loginPassword = it },
                label = { Text(when (lang) {
                    "gu" -> "સુરક્ષા પાસવર્ડ"
                    "hi" -> "सुरक्षा पासवर्ड"
                    else -> "Security Password"
                }, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp)) },
                trailingIcon = {
                    IconButton(onClick = { showLoginPassword = !showLoginPassword }) {
                        Icon(
                            imageVector = if (showLoginPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Password",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                visualTransformation = if (showLoginPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Remember Me & Forgot Password Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = rememberMe,
                        onCheckedChange = { rememberMe = it },
                        colors = CheckboxDefaults.colors(checkedColor = primaryTeal),
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (lang) {
                            "gu" -> "યાદ રાખો"
                            "hi" -> "मुझे याद रखें"
                            else -> "Remember me"
                        },
                        fontSize = 12.sp,
                        color = Color(0xFF475569)
                    )
                }

                Text(
                    text = when (lang) {
                        "gu" -> "પાસવર્ડ ભૂલી ગયા છો?"
                        "hi" -> "पासवर्ड रीसेट करें"
                        else -> "Reset Password"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = primaryTeal,
                    modifier = Modifier.clickable {
                        forgotMobile = loginMobile
                        showForgotDialog = true
                    }
                )
            }

            Spacer(modifier = Modifier.height(9.dp))

            // Login Button (Compact 42-44dp height)
            Button(
                onClick = {
                    if (loginMobile.length != 10) {
                        loginError = when (lang) {
                            "gu" -> "કૃપા કરીને માન્ય ૧૦-અંકનો મોબાઇલ નંબર દાખલ કરો"
                            "hi" -> "कृपया मान्य 10-अंकीय मोबाइल नंबर दर्ज करें"
                            else -> "Please enter valid 10-digit mobile number"
                        }
                        return@Button
                    }
                    if (loginPassword.isBlank()) {
                        loginError = when (lang) {
                            "gu" -> "કૃપા કરીને તમારો પાસવર્ડ દાખલ કરો"
                            "hi" -> "कृपया अपना पासवर्ड दर्ज करें"
                            else -> "Please enter your password"
                        }
                        return@Button
                    }

                    // Check user credentials from secure device storage (NO hardcoded password)
                    val savedPassword = sharedPrefs.getString("password_$loginMobile", null)
                        ?: sharedPrefs.getString("mpin_$loginMobile", null)
                    val savedName = sharedPrefs.getString("name_$loginMobile", "ASHA Worker")
                    
                    if (savedPassword == null) {
                        loginError = when (lang) {
                            "gu" -> "આ મોબાઇલ નંબર નોંધાયેલ નથી. કૃપા કરીને પ્રથમ નવી નોંધણી કરો."
                            "hi" -> "यह मोबाइल नंबर पंजीकृत नहीं है। कृपया पहले नया पंजीकरण करें।"
                            else -> "Account not registered. Please register first."
                        }
                    } else if (savedPassword != loginPassword) {
                        loginError = when (lang) {
                            "gu" -> "ખોટો પાસવર્ડ. કૃપા કરીને ફરી પ્રયાસ કરો."
                            "hi" -> "गलत पासवर्ड। कृपया पुनः प्रयास करें।"
                            else -> "Incorrect password. Please try again."
                        }
                    } else {
                        sharedPrefs.edit()
                            .putBoolean("ashaLoggedIn", true)
                            .putString("activeUserMobile", loginMobile)
                            .putString("activeUserName", savedName ?: "ASHA Worker")
                            .apply()
                        onLoginSuccess(loginMobile, savedName ?: "ASHA Worker")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = primaryTeal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            ) {
                Text(
                    text = when (lang) {
                        "gu" -> "લૉગિન કરો"
                        "hi" -> "लॉगिन करें"
                        else -> "Sign In"
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            // === NEW REGISTRATION TAB ===
            if (regError.isNotEmpty()) {
                Surface(
                    color = Color(0xFFFFF1F2),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Text(
                        text = regError,
                        color = Color(0xFFBE123C),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (regSuccess.isNotEmpty()) {
                Surface(
                    color = Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Text(
                        text = regSuccess,
                        color = Color(0xFF15803D),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Full Name Field (Compact 50dp height, 15sp text)
            OutlinedTextField(
                value = regName,
                onValueChange = { regName = it },
                label = { Text(when (lang) {
                    "gu" -> "આશા કાર્યકરનું પૂરું નામ"
                    "hi" -> "आशा कार्यकर्ता का पूरा नाम"
                    else -> "ASHA Worker Full Name"
                }, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp)) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            )

            Spacer(modifier = Modifier.height(11.dp))

            // Registered Mobile Number Field (Compact 50dp height, 15sp text)
            OutlinedTextField(
                value = regMobile,
                onValueChange = { if (it.length <= 10) regMobile = it.filter { ch -> ch.isDigit() } },
                label = { Text(when (lang) {
                    "gu" -> "નોંધાયેલ મોબાઇલ નંબર"
                    "hi" -> "पंजीकृत मोबाइल नंबर"
                    else -> "Registered Mobile Number"
                }, fontSize = 13.sp) },
                leadingIcon = { Text("+91 ", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF64748B), modifier = Modifier.padding(start = 12.dp)) },
                trailingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            )

            Spacer(modifier = Modifier.height(11.dp))

            // Create Security Password Field (Compact 50dp height, 15sp text, ONLY ONE password field, no confirm password)
            OutlinedTextField(
                value = regPassword,
                onValueChange = { regPassword = it },
                label = { Text(when (lang) {
                    "gu" -> "નવો પાસવર્ડ બનાવો"
                    "hi" -> "नया सुरक्षा पासवर्ड बनाएं"
                    else -> "Create Security Password"
                }, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp)) },
                trailingIcon = {
                    IconButton(onClick = { showRegPassword = !showRegPassword }) {
                        Icon(
                            imageVector = if (showRegPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Password",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                visualTransformation = if (showRegPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            )

            Spacer(modifier = Modifier.height(11.dp))

            // Registration Button (Compact 50dp height)
            Button(
                onClick = {
                    if (regName.isBlank()) {
                        regError = when (lang) {
                            "gu" -> "કૃપા કરીને પૂરું નામ દાખલ કરો"
                            "hi" -> "कृपया पूरा नाम दर्ज करें"
                            else -> "Please enter your full name"
                        }
                        return@Button
                    }
                    if (regMobile.length != 10) {
                        regError = when (lang) {
                            "gu" -> "કૃપા કરીને ૧૦-અંકનો મોબાઇલ નંબર દાખલ કરો"
                            "hi" -> "कृपया 10-अंकीय मोबाइल नंबर दर्ज करें"
                            else -> "Please enter 10-digit mobile number"
                        }
                        return@Button
                    }
                    if (regPassword.isBlank()) {
                        regError = when (lang) {
                            "gu" -> "કૃપા કરીને માન્ય પાસવર્ડ દાખલ કરો"
                            "hi" -> "कृपया मान्य पासवर्ड बनाएं"
                            else -> "Please enter valid password"
                        }
                        return@Button
                    }

                    // Save user credentials securely to device storage
                    sharedPrefs.edit()
                        .putString("password_$regMobile", regPassword)
                        .putString("mpin_$regMobile", regPassword)
                        .putString("name_$regMobile", regName)
                        .putBoolean("ashaLoggedIn", true)
                        .putString("activeUserMobile", regMobile)
                        .putString("activeUserName", regName)
                        .apply()

                    regSuccess = when (lang) {
                        "gu" -> "નોંધણી સફળ થઈ! તમે હવે લૉગિન કરી શકો છો."
                        "hi" -> "पंजीकरण सफल! अब आप लॉगिन कर सकते हैं।"
                        else -> "Registration successful! You can now log in."
                    }
                    loginMobile = regMobile
                    loginPassword = regPassword
                    onLoginSuccess(regMobile, regName)
                },
                colors = ButtonDefaults.buttonColors(containerColor = primaryTeal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(
                    text = when (lang) {
                        "gu" -> "નોંધણી કરો અને એકાઉન્ટ બનાવો"
                        "hi" -> "पंजीकरण करें और खाता बनाएं"
                        else -> "Register & Create Account"
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // --- 5. Footer / Version Information ---
        Text(
            text = "Ministry of Health & Family Welfare • National Health Mission",
            fontSize = 9.sp,
            color = Color(0xFF94A3B8),
            textAlign = TextAlign.Center
        )
        Text(
            text = "v1.2.5 • Secured On-Device Storage",
            fontSize = 9.sp,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
        }
    }

    // --- Reset Password Dialog ---
    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = { showForgotDialog = false },
            title = {
                Text(
                    text = when (lang) {
                        "gu" -> "પાસવર્ડ રીસેટ કરો"
                        "hi" -> "पासवर्ड रीसेट करें"
                        else -> "Reset Password"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (forgotError.isNotEmpty()) {
                        Text(forgotError, color = Color.Red, fontSize = 11.sp)
                    }
                    OutlinedTextField(
                        value = forgotMobile,
                        onValueChange = { forgotMobile = it },
                        label = { Text("Mobile Number") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = enteredOtp,
                        onValueChange = { enteredOtp = it },
                        label = { Text("Enter OTP (Use 4821)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("New Password") },
                        visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showNewPassword = !showNewPassword }) {
                                Icon(
                                    imageVector = if (showNewPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle"
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (enteredOtp != "4821") {
                            forgotError = "Invalid OTP"
                            return@Button
                        }
                        if (newPassword.length < 3) {
                            forgotError = "Password too short"
                            return@Button
                        }
                        sharedPrefs.edit()
                            .putString("password_$forgotMobile", newPassword)
                            .putString("mpin_$forgotMobile", newPassword)
                            .apply()
                        loginMobile = forgotMobile
                        loginPassword = newPassword
                        showForgotDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = primaryTeal)
                ) {
                    Text("Verify & Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
