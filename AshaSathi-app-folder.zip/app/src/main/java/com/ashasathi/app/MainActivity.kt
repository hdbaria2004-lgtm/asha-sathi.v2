package com.ashasathi.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- Data Models ---
data class Beneficiary(
    val id: String,
    val name: String,
    val age: Int,
    val husbandName: String,
    val village: String,
    val phone: String,
    val abhaId: String,
    val category: String, // "Maternal" or "Child"
    val lmpDate: String = "",
    val eddDate: String = "",
    val isHighRisk: Boolean = false,
    val highRiskReason: String = "",
    val ancCompleted: Int = 0,
    val childAgeMonths: Int = 0,
    val nextVaccine: String = ""
)

data class DailyTask(
    val id: String,
    val title: String,
    val beneficiaryName: String,
    val village: String,
    val dueDate: String,
    val type: String, // "ANC Checkup", "Immunization", "Home Visit"
    val isCompleted: Boolean = false
)

data class AshaIncentive(
    val title: String,
    val code: String,
    val rate: Int,
    val completedCount: Int,
    val totalClaim: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AshaSathiApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AshaSathiApp() {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("asha_sathi_auth", Context.MODE_PRIVATE) }
    
    // Check persistent login state: skips login screen on app restart if ashaLoggedIn is true
    var isLoggedIn by remember { 
        mutableStateOf(sharedPrefs.getBoolean("ashaLoggedIn", false)) 
    }
    var currentTab by remember { mutableIntStateOf(0) }
    var isHindi by remember { mutableStateOf(true) }

    val primaryTeal = Color(0xFF0D9488)
    val lightTeal = Color(0xFFF0FDFA)

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = primaryTeal,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFCCFBF1),
            surface = Color.White,
            background = Color(0xFFF8FAFC)
        )
    ) {
        if (!isLoggedIn) {
            LoginScreen(
                onLoginSuccess = { mobile, name ->
                    // Save login state persistently in SharedPreferences
                    sharedPrefs.edit()
                        .putBoolean("ashaLoggedIn", true)
                        .putString("activeUserMobile", mobile)
                        .putString("activeUserName", name)
                        .apply()
                    isLoggedIn = true
                    currentTab = 0
                },
                lang = if (isHindi) "hi" else "en",
                onLanguageChange = { isHindi = (it == "hi") }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = if (isHindi) "आशा साथी (ASHA Sathi)" else "Asha Sathi",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isHindi) "प्राथमिक स्वास्थ्य साथी • ग्राम कल्याण" else "Community Health Companion",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        },
                        actions = {
                            TextButton(
                                onClick = { isHindi = !isHindi },
                                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                            ) {
                                Text(
                                    text = if (isHindi) "English" else "हिंदी",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = primaryTeal
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        val tabs = listOf(
                            Triple(if (isHindi) "डैशबोर्ड" else "Home", Icons.Default.Home, 0),
                            Triple(if (isHindi) "हितग्राही" else "Beneficiaries", Icons.Default.People, 1),
                            Triple(if (isHindi) "कार्य सूची" else "Tasks", Icons.Default.Checklist, 2),
                            Triple(if (isHindi) "प्रोत्साहन" else "Incentives", Icons.Default.Payments, 3),
                            Triple(if (isHindi) "आपातकाल" else "SOS", Icons.Default.PhoneInTalk, 4),
                            Triple(if (isHindi) "सेटिंग्स" else "Settings", Icons.Default.Settings, 5)
                        )
                        tabs.forEach { (label, icon, index) ->
                            NavigationBarItem(
                                selected = currentTab == index,
                                onClick = { currentTab = index },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = primaryTeal,
                                    selectedTextColor = primaryTeal,
                                    indicatorColor = lightTeal
                                )
                            )
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .background(Color(0xFFF8FAFC))
                ) {
                    when (currentTab) {
                        0 -> DashboardScreen(isHindi = isHindi, onNavigateTo = { currentTab = it })
                        1 -> BeneficiariesScreen(isHindi = isHindi)
                        2 -> TasksScreen(isHindi = isHindi)
                        3 -> IncentivesScreen(isHindi = isHindi)
                        4 -> EmergencyScreen(isHindi = isHindi)
                        5 -> SettingsScreen(
                            currentLang = if (isHindi) "hi" else "en",
                            onLangSelected = { isHindi = (it == "hi") },
                            isDarkTheme = false,
                            onThemeToggle = {},
                            onLogout = {
                                // Explicit user logout: clear persistent SharedPreferences flag
                                sharedPrefs.edit()
                                    .putBoolean("ashaLoggedIn", false)
                                    .apply()
                                isLoggedIn = false
                                currentTab = 0
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(isHindi: Boolean, onNavigateTo: (Int) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Welcome Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isHindi) "नमस्ते, सुनीता देवी (ASHA)" else "Welcome, Sunita Devi (ASHA)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            Text(
                                text = if (isHindi) "उप-केंद्र: रामपुर | वार्ड 4" else "Sub-Centre: Rampur | Ward 4",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 13.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.White)
                        }
                    }
                }
            }
        }

        item {
            // Quick Metric Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = if (isHindi) "गर्भवती माताएं" else "Pregnant Mothers",
                    count = "18",
                    icon = Icons.Default.PregnantWoman,
                    color = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = if (isHindi) "शिशु (0-2 वर्ष)" else "Infants (0-2y)",
                    count = "34",
                    icon = Icons.Default.ChildCare,
                    color = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = if (isHindi) "उच्च जोखिम अलर्ट" else "High Risk Alerts",
                    count = "3",
                    icon = Icons.Default.Warning,
                    color = Color(0xFFE11D48),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = if (isHindi) "मासिक प्रोत्साहन" else "Monthly Incentive",
                    count = "₹4,200",
                    icon = Icons.Default.AccountBalanceWallet,
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text(
                text = if (isHindi) "आज के महत्वपूर्ण कार्य" else "Today's Due Tasks",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF1E293B)
            )
        }

        items(getSampleTasks().take(3)) { task ->
            TaskItemCard(task = task, isHindi = isHindi)
        }
    }
}

@Composable
fun StatCard(
    title: String,
    count: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = count, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
            Text(text = title, fontSize = 12.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
fun TaskItemCard(task: DailyTask, isHindi: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFE0F2FE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Event, contentDescription = null, tint = Color(0xFF0284C7))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = task.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    text = "${task.beneficiaryName} • ${task.village}",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            AssistChip(
                onClick = {},
                label = { Text(if (isHindi) "आज" else "Due", fontSize = 11.sp) }
            )
        }
    }
}

@Composable
fun BeneficiariesScreen(isHindi: Boolean) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    val beneficiaries = remember { getSampleBeneficiaries() }

    val filtered = beneficiaries.filter {
        (selectedFilter == "All" || it.category == selectedFilter) &&
                (it.name.contains(searchQuery, ignoreCase = true) || it.village.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (isHindi) "नाम या गाँव खोजें..." else "Search by name or village...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilter == "All",
                onClick = { selectedFilter = "All" },
                label = { Text(if (isHindi) "सभी" else "All") }
            )
            FilterChip(
                selected = selectedFilter == "Maternal",
                onClick = { selectedFilter = "Maternal" },
                label = { Text(if (isHindi) "गर्भवती माताएं" else "Maternal") }
            )
            FilterChip(
                selected = selectedFilter == "Child",
                onClick = { selectedFilter = "Child" },
                label = { Text(if (isHindi) "शिशु" else "Children") }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { item ->
                BeneficiaryCard(b = item, isHindi = isHindi)
            }
        }
    }
}

@Composable
fun BeneficiaryCard(b: Beneficiary, isHindi: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = b.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = if (isHindi) "पति: ${b.husbandName} | आयु: ${b.age} वर्ष" else "Husband: ${b.husbandName} | Age: ${b.age}y",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
                if (b.isHighRisk) {
                    AssistChip(
                        onClick = {},
                        label = { Text(if (isHindi) "उच्च जोखिम" else "High Risk", color = Color(0xFFE11D48), fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "गाँव: ${b.village}",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
                Text(
                    text = "ABHA: ${b.abhaId}",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
            }
        }
    }
}

@Composable
fun TasksScreen(isHindi: Boolean) {
    val tasks = remember { getSampleTasks() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = if (isHindi) "दैनिक कार्य व गृह भेंट सूची" else "Daily Tasks & Home Visits",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
        items(tasks) { task ->
            TaskItemCard(task = task, isHindi = isHindi)
        }
    }
}

@Composable
fun IncentivesScreen(isHindi: Boolean) {
    val incentives = listOf(
        AshaIncentive("जननी सुरक्षा योजना (JSY)", "JSY-01", 600, 4, 2400),
        AshaIncentive("नियमित टीकाकरण (Full Immunization)", "RI-02", 150, 6, 900),
        AshaIncentive("गृह आधारित नवजात शिशु देखभाल (HBNC)", "HBNC-03", 250, 3, 750),
        AshaIncentive("प्रधानमंत्री सुरक्षित मातृत्व अभियान (PMSMA)", "PMSMA-04", 150, 1, 150)
    )
    val grandTotal = incentives.sumOf { it.totalClaim }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF047857)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "कुल मासिक दावा (सितंबर 2026)" else "Total Monthly Claim (Sept 2026)",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp
                    )
                    Text(
                        text = "₹$grandTotal",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        items(incentives) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(text = "दर: ₹${item.rate} × ${item.completedCount} प्रकरण", fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                    Text(text = "₹${item.totalClaim}", fontWeight = FontWeight.Bold, color = Color(0xFF047857))
                }
            }
        }
    }
}

@Composable
fun EmergencyScreen(isHindi: Boolean) {
    val context = LocalContext.current
    val emergencyContacts = listOf(
        Triple("एम्बुलेंस (108)", "108", Icons.Default.LocalHospital),
        Triple("मातृ एवं शिशु एम्बुलेंस (102)", "102", Icons.Default.Emergency),
        Triple("प्राथमिक स्वास्थ्य केंद्र (PHC रामपुर)", "+91 9876543210", Icons.Default.MedicalServices),
        Triple("एएनएम (ANM रेखा शर्मा)", "+91 9876501234", Icons.Default.Person)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFBE123C)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "आपातकालीन स्वास्थ्य सहायता (SOS)" else "Emergency Health Helpline",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHindi) "गंभीर स्थिति में तुरंत सहायता के लिए कॉल करें" else "Direct one-touch call in case of delivery or emergency",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )
                }
            }
        }

        items(emergencyContacts) { (label, number, icon) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                        context.startActivity(intent)
                    },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFE4E6)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = Color(0xFFBE123C))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = number, fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                    Icon(Icons.Default.Phone, contentDescription = "Call", tint = Color(0xFF0D9488))
                }
            }
        }
    }
}

fun getSampleBeneficiaries(): List<Beneficiary> {
    return listOf(
        Beneficiary(
            id = "B01",
            name = "पूजा देवी",
            age = 22,
            husbandName = "राजेश कुमार",
            village = "रामपुर",
            phone = "9876541201",
            abhaId = "12-3456-7890-1234",
            category = "Maternal",
            lmpDate = "15 Jan 2026",
            eddDate = "22 Oct 2026",
            isHighRisk = true,
            highRiskReason = "गंभीर एनीमिया (Hb < 8 g/dl)",
            ancCompleted = 2
        ),
        Beneficiary(
            id = "B02",
            name = "मीरा बाई",
            age = 25,
            husbandName = "मोहन सिंह",
            village = "रामपुर",
            phone = "9876541202",
            abhaId = "12-3456-7890-5678",
            category = "Maternal",
            lmpDate = "02 Feb 2026",
            eddDate = "09 Nov 2026",
            isHighRisk = false,
            ancCompleted = 3
        ),
        Beneficiary(
            id = "B03",
            name = "आरव (शिशु)",
            age = 0,
            husbandName = "माता: कविता देवी",
            village = "विशनपुर",
            phone = "9876541203",
            abhaId = "12-3456-7890-9988",
            category = "Child",
            childAgeMonths = 9,
            nextVaccine = "MR 1st Dose + Vitamin A"
        )
    )
}

fun getSampleTasks(): List<DailyTask> {
    return listOf(
        DailyTask("T1", "तृतीय ANC जांच (ANC 3rd Checkup)", "पूजा देवी", "रामपुर", "आज", "ANC Checkup"),
        DailyTask("T2", "पेंटावेलेंट 3 व पोलियो टीका", "आरव (शिशु)", "विशनपुर", "आज", "Immunization"),
        DailyTask("T3", "प्रसव पश्चात गृह भेंट (PNC Visit 3)", "संगीता देवी", "रामपुर", "कल", "Home Visit")
    )
}
